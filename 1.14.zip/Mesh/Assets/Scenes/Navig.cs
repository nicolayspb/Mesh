using UnityEngine;
using UnityEngine.AI;

public class Navig : MonoBehaviour
{
    public Transform Target;
    private NavMeshAgent Agent;

    private void Awake()
    {
        Agent = GetComponent<NavMeshAgent>();
    }

    void Update()
    {
        Agent.destination = Target.position;
    }
}
